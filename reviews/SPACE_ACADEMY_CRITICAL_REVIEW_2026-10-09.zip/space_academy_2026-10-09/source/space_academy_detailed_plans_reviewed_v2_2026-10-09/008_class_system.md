# 8. Class System

**Nguồn gốc:** `SPACE_ACADEMY_PRODUCT_VISION_AND_SYSTEM_IDEAS_REVIEW_DRAFT_2026-10-09.md`  
**Loại:** Subsystem detailed design  
**Primary owner/domain:** `classroom`  
**Secondary integrations:** social  
**Review status:** Self-reviewed V2 — domain ownership corrected; vẫn là draft cần Claude/architecture review trước implementation.

---

## 1. Mục tiêu

Xây lớp như một môi trường học xã hội có lịch, identity, teacher/NPC, lesson và lịch sử chung.

### Điều phải giữ riêng cho mục này

- Class phải có capacity/timezone/track/teacher/theme/session history.
- Main class 15–30 người là giả thuyết cần thử nghiệm.

---

## 2. Ý tưởng gốc đã thống nhất

The class is one of the most important long-term retention systems because people return for people they know.

A class should not be only:

```text
Name
Member list
Chat
Assignments
```

It should have identity and history.

## 8.1 Example class

```text
CLASS ORION-7

Level: B1 → B2
Track: General English
Members: 24
Teacher: Professor Lyra
Specialty: Science & Technology
Class Rank: Silver III
```

## 8.2 Class identity

Potential class-specific elements:

- Name
- Banner
- Crest
- Color/theme
- Background
- NPC / teacher
- Soundtrack
- Topic personality
- Trophy shelf
- Class history
- Current goals

Classes can reuse a shared visual kit with different themes instead of requiring completely unique assets.

## 8.3 Suggested class size

Initial target:

> approximately 15–30 learners per main class.

Reasons:

- Small enough to remember classmates
- Large enough for social activity
- Teacher can manage it
- Rankings remain meaningful
- Chat remains readable

A user might belong to:

- 1 main class
- optional course(s)
- 1 club/crew-like social group

Avoid encouraging users to join dozens of classes.

---

---

## 3. Phạm vi V1 đề xuất

### Core

- Chỉ triển khai behavior trực tiếp phục vụ mục tiêu của mục này.
- Server là authority cho progress, reward, ownership, ranking hoặc permission có giá trị.
- Client tối ưu presentation, optimistic feedback và cache; không tự quyết định state giá trị cao.
- Data/config có lifecycle thì dùng version rõ ràng.
- Có empty/loading/error/retry state.

### Không đưa vào V1 nếu chưa có bằng chứng

- Realtime chỉ để “trông hiện đại”.
- Animation/VFX phức tạp không giúp comprehension/identity.
- Schema riêng cho state có thể derive an toàn.
- Integration chéo bằng cách query thẳng bảng của module khác.
- Feature phụ chỉ vì game online khác có.

---

## 4. User flow

```text
DISCOVER
  ↓
UNDERSTAND
  ↓
ACT
  ↓
FEEDBACK
  ↓
CONTINUE / RETURN
```

1. **Discover:** user hiểu feature là gì mà không đọc tutorial dài.
2. **Understand:** rule, cost, reward hoặc learning objective minh bạch.
3. **Act:** primary action ít bước.
4. **Feedback:** kết quả rõ, pending/failed/retry nếu async.
5. **Continue:** CTA hợp logic hoặc kết thúc sạch, không ép sang Shop/Event.

---

## 5. UI/UX

- Before/During/After class là 3 state UX khác nhau.
- Trong giờ học lesson là trung tâm; chat/participants là secondary.
- Class identity dùng theme skin trên shared layout.

### UX guardrails chung

- Một primary CTA/màn hình.
- Không dùng badge đỏ/chấm than khắp UI.
- Secondary/meta systems không chiếm visual weight hơn learning task.
- Mobile thiết kế theo mật độ riêng, không chỉ scale desktop.
- Keyboard/focus/contrast/reduced-motion được tính ngay từ đầu.
- Error message phải chỉ cách phục hồi.

---

## 6. Hình ảnh / Art

- Shared classroom kit + banner/crest/background/teacher art để vừa khác biệt vừa tiết kiệm asset.
- NPC dùng portrait/half-body + expression, không cần animation nặng.

### Asset rules

- Mỗi asset có ID, version/hash, provenance/owner khi cần.
- List dùng thumbnail; full asset chỉ tải khi thực sự cần.
- Template/safe area/crop/alpha/naming được chuẩn hóa.
- Không hard-code file path vào business rules.

---

## 7. Âm thanh

- Class start/end cue nhẹ; teacher voice ưu tiên ambience.
- Break bell và notification có setting/cooldown.

### Audio guardrails

- Voice/pronunciation > music > cosmetic SFX về priority.
- Có mute/volume theo group khi domain có audio.
- Notification cue có cooldown.
- Không autoplay audio dài chỉ vì mở screen.
- Mobile autoplay restriction phải có user gesture fallback.

---

## 8. Motion / VFX

- Animation mặc định dùng transform/opacity khi đủ.
- Reduced-motion có fallback tĩnh.
- Effect hiếm mới fullscreen.
- Dừng effect off-screen/hidden tab.
- Quality tier giảm blur/shadow/particles trên thiết bị yếu.
- Motion phải giải thích state hoặc tạo cảm xúc có chủ đích; nếu chỉ trang trí và tốn GPU thì bỏ.

---

## 9. Database / Data ownership

- `classes`, `class_memberships`, `class_schedules`, `class_sessions`, `class_progress`, `class_achievements`.
- `class_sessions` snapshot lesson version + schedule để lịch sử không đổi khi content publish bản mới.

### Data rules

- PostgreSQL là transactional source of truth.
- Redis chỉ cache/realtime/ranking khi có use case rõ.
- Media nằm object storage/CDN.
- Mutation có thể retry phải idempotent.
- JSONB cho config mở rộng; field query thường xuyên nên thành column/index.
- Historical result đã finalize không sửa tùy tiện.
- Mọi timestamp business quan trọng dùng server time; timezone chỉ dùng để resolve user-facing calendar/day boundary.

---

## 10. API / Domain events

- `class.session.started`
- `class.session.completed`
- `class.member.joined`
- `class.progress.changed`

### Contract rules

- Không query DB cross-module trực tiếp nếu có thể dùng service/domain contract.
- Mutation validate authorization + eligibility phía server.
- Cursor pagination cho collection lớn.
- API list trả summary DTO, không full aggregate.
- Event payload có stable IDs + schema version.

---

## 11. Tích hợp với subsystem khác

- **social**: tích hợp qua events/contracts; không copy schema/UI của domain này vào module `classroom`.

**Nguyên tắc:** secondary integration không đồng nghĩa nhập toàn bộ UI/DB của domain đó vào file này. Đây là lỗi đã được sửa so với bản generated đầu tiên.

---

## 12. Admin / Configuration

- Chỉ config những gì operator/teacher thật sự cần thay đổi thường xuyên.
- Live config: `draft → preview → publish`.
- Có audit actor/time/reason.
- Economy/prestige/reward config cần permission cao hơn.
- Không để admin sửa thẳng historical result đã finalized.
- Config có thời hạn phải có start/end/timezone policy rõ.

---

## 13. Performance

- Presence/chat subscribe theo class room, không global.
- List participant chỉ tải thumbnail; full avatar lazy-load.
- Lesson payload immutable/versioned và cacheable.

### Budget guardrails

- Feature không thuộc Home critical path thì code-split/lazy-load.
- Không giữ realtime subscription khi user rời context.
- List media responsive theo viewport.
- Tránh long task do animation/large JSON.
- Đo trên thiết bị yếu đại diện, không chỉ máy dev.
- Theo dõi p95 API, asset failure, interaction latency, memory growth.

---

## 14. Security / Abuse / Safety

- Không tin client score/time/balance/eligibility.
- Rate limit các action spam-able.
- Reward/purchase/prestige cần audit/idempotency khi phù hợp.
- Social feature phải có moderation primitives tương ứng.
- PII tối thiểu.
- AI/NPC không giả làm người thật.
- Nếu target minors, cần privacy/safety review riêng trước launch.

---

## 15. Analytics / KPI

Không tối ưu chỉ theo **time spent**.

Đo tối thiểu:

- Primary-action completion
- Return rate theo persona
- Abandon/error rate
- Time-to-primary-action
- Feature load time
- Learning outcome/mistake reduction nếu liên quan học
- Healthy engagement: opt-out/mute/notification-dismiss khi liên quan social/reward
- Economy source/sink hoặc rank integrity nếu thuộc domain đó

---

## 16. Testing / Acceptance

### Functional

- Happy path.
- Empty/loading/error/retry.
- Refresh/reconnect.
- Concurrent/double-click.
- Mobile/touch.
- Keyboard/accessibility.
- Reduced-motion/mute.
- Permission/eligibility.
- Version compatibility.

### Data

- Không duplicate grant/progress khi retry.
- Migration forward/rollback plan.
- Index query chính được kiểm tra.
- Audit trail cho state giá trị cao.

### Performance

- Route chunk/media không vượt budget đã khóa.
- Không memory leak sau nhiều navigation.
- Network slow/offline có graceful behavior khi hợp lý.

---

## 17. Rollout

### A. Prototype
Validate UX/art/content bằng fixture, chưa xây backend quá sâu.

### B. Foundation
Schema/API tối thiểu + analytics + basic admin.

### C. Production V1
Real data + mobile + error/retry + performance budget.

### D. Enrichment
Chỉ thêm live/social/VFX/cosmetic depth khi core metrics chứng minh có giá trị.

---

## 18. Claude review checklist

Claude nên đánh dấu **Keep / Simplify / Postpone / Reject** và trả lời:

1. Scope này có quá lớn không?
2. Primary owner/domain đã đúng chưa?
3. Có duplicate source of truth không?
4. DB có over-normalized hoặc quá generic không?
5. UI có đủ đơn giản với casual learner không?
6. Visual/audio có lấn learning không?
7. Performance web/mobile có hợp lý không?
8. Có FOMO/dark pattern/cheat vector không?
9. V1 có thể cắt thêm gì?
10. Dependency nào nên chuyển sang event/contract?

---

## 19. Definition of Done

Chỉ coi là hoàn thành khi:

- Functional + integration tests pass.
- Analytics hoạt động.
- Mobile/accessibility smoke pass.
- Performance budget pass.
- Data ownership và idempotency rõ.
- Admin/config path được test nếu có.
- Không còn hidden dependency vào module khác.
- Documentation/ADR cập nhật.

---

## 20. Kết luận

`Class System` phải phục vụ trực tiếp cho **classroom**. Các hệ liên quan chỉ tích hợp qua contract, không được khiến file này trở thành một “siêu module” ôm class + reward + avatar + event + typing cùng lúc.

Đây là nguyên tắc quan trọng để giữ sản phẩm **đẹp, dễ hiểu, hiệu năng tốt và có thể mở rộng lâu dài**.
